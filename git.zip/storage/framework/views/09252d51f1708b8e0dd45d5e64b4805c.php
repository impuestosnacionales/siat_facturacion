<?php $__env->startSection('name'); ?>
    Logos y configuración
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<hr>
<a href="<?php echo e(route('impresion.create')); ?>" class="btn btn-primary" role="button">Añadir <i class="bi bi-plus-square"></i></a>
</div>
<div class="card-body">
<table id="tab" class="table">
<tr>
<th>Impresion</th>
<th>Logo</th>
<th>Acciones</th>
</tr>
<?php $__currentLoopData = $impresion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $impresion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($impresion->tipoimp); ?></td>
<td><img src="<?php echo e($impresion->logo); ?>" width="100"></td>
<td>
<form action="<?php echo e(route('impresion.destroy', $impresion->id)); ?>" method="POST" onsubmit="return confirm('¿Estás seguro de que deseas eliminar este logo?');">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>
<button type="submit" class="btn btn-danger">Eliminar <i class="bi bi-trash"></i></button>
</form>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
</div>


</div>
</div>
</div>
</main>
</div>
</div>
<?php $__env->stopSection(); ?>
            
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siat_facturacion\resources\views/Impresion/impresion.blade.php ENDPATH**/ ?>