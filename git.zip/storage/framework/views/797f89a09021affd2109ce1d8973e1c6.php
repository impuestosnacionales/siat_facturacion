<?php $__env->startSection('name'); ?>
    Reporte de Facturas de compra y venta
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<table id="tab" class="table">
    <thead>
        <tr>
            <th>N°</th>
            <th>Casos Especiales</th>
            <th>Fecha</th>
            <th>Sucursal</th>
            <th>Actividad Económica</th>
            <th>Tipo de Documento</th>
            <th>Nombre Razón Social</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $factura; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($factura->id); ?></td>
            <td><?php echo e($factura->casos_esp); ?></td>
            <td><?php echo e($factura->fecha); ?></td>
            <td><?php echo e($factura->sucursal); ?></td>
            <td><?php echo e($factura->actividad); ?></td>
            <td><?php echo e($factura->tipodoc); ?></td>
            <td><?php echo e($factura->razons); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/schatzen/public_html/panchito.schatzencode.com/resources/views/Facturas/factura_tabla.blade.php ENDPATH**/ ?>