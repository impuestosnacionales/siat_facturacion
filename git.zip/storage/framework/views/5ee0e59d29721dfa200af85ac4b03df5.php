<?php $__env->startSection('name'); ?>
    Gráficos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div style="display: flex; justify-content: space-around;">
        <div style="width: 30%;">
            <canvas id="barChart"></canvas>
        </div>
        <div style="width: 30%;">
            <canvas id="pieChart"></canvas>
        </div>
        <div style="width: 30%;">
            <canvas id="lineChart"></canvas>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns"></script>
    <script>
        
    </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/schatzen/public_html/panchito.schatzencode.com/resources/views/home.blade.php ENDPATH**/ ?>