<?php $__env->startSection('name'); ?>
    Lista de Roles
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<a data-bs-toggle="modal" data-bs-target="#ModalAñadirRol" class="btn btn-success" role="button">Nuevo Rol <i class="fa-regular fa-square-plus"></i></a>
<hr>

<!-- Modal para Añadir Rol -->
<div class="modal fade" id="ModalAñadirRol" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Añadir Rol</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('rol.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-outline mb-4">
                        <label class="form-label" for="formNombre">Nombre</label>
                        <input type="text" name="name" class="form-control" placeholder="Ingresa el Nombre" required/>
                    </div>
                    <div class="form-outline mb-4">
                        <label class="form-label" for="formDescripcion">Guard Name</label>
                        <input type="text" name="guard_name" class="form-control" placeholder="Ingresa el Guard Name" required/>
                    </div>
                    <button type="submit" class="btn btn-primary">Crear</button>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="col-12 col-md-12 justify-content-center">
  <table id="tab" class="table table-bordered table-striped">
      <thead>
          <tr>
              <th>Id</th>
              <th>Nombre</th>
              <th>Acciones</th>
          </tr>
      </thead>
      <tbody>
          <?php $__currentLoopData = $rol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
              <td><?php echo e($rol->id); ?></td>
              <td><?php echo e($rol->name); ?></td>
              <td>
                  <button type="button" class="btn btn-outline-success" data-bs-toggle="modal" data-bs-target="#ModalMostrar<?php echo e($rol->id); ?>">Ver</button>
                  <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#ModalEditar<?php echo e($rol->id); ?>">Editar</button>
                  <form action="<?php echo e(route('rol.destroy', $rol->id)); ?>" method="POST" style="display:inline;">
                      <?php echo csrf_field(); ?>
                      <?php echo e(method_field('DELETE')); ?>

                      <button class="btn btn-danger" type="submit" onclick="return confirm('¿Estás seguro de eliminar este rol?')">Eliminar</button>
                  </form>
              </td>
          </tr>

          <!-- Modal para Mostrar Detalles del Rol -->
          <div class="modal fade" id="ModalMostrar<?php echo e($rol->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-lg">
                  <div class="modal-content">
                      <div class="modal-header">
                          <h1 class="modal-title fs-5" id="exampleModalLabel">Detalles del Rol</h1>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                          <div class="mb-3">
                              <label class="form-label"><strong>Nombre:</strong></label>
                              <p><?php echo e($rol->name); ?></p>
                          </div>
                          <div class="mb-3">
                              <label class="form-label"><strong>Guard Name:</strong></label>
                              <p><?php echo e($rol->guard_name); ?></p>
                          </div>
                      </div>
                  </div>
              </div>
          </div>

          <!-- Modal para Editar Rol -->
          <div class="modal fade" id="ModalEditar<?php echo e($rol->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog">
                  <div class="modal-content">
                      <div class="modal-header">
                          <h1 class="modal-title fs-5" id="exampleModalLabel">Editar Rol</h1>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                          <form action="<?php echo e(route('rol.update', $rol->id)); ?>" method="post">
                              <?php echo csrf_field(); ?>
                              <?php echo e(method_field('PUT')); ?>

                              <div class="mb-3">
                                  <label class="form-label">Nombre del rol:</label>
                                  <input type="text" name="name" value="<?php echo e($rol->name); ?>" class="form-control" required>
                              </div>
                              <div class="mb-3">
                                  <label class="form-label">Guard Name:</label>
                                  <input type="text" name="guard_name" value="<?php echo e($rol->guard_name); ?>" class="form-control" required>
                              </div>
                              <button type="submit" class="btn btn-primary">Actualizar</button>
                          </form>
                      </div>
                  </div>
              </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
  </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/schatzen/public_html/panchito.schatzencode.com/resources/views/Rol/rol.blade.php ENDPATH**/ ?>