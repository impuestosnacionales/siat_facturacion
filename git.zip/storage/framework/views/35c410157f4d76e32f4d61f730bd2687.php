<?php $__env->startSection('name'); ?>
  Asignar Roles a usuarios
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <table id="tab" class="table table-bordered table-striped">
    <thead>
      <tr>
          
          <table id="tab" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($user->id); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td>
                    <a data-bs-toggle="modal" data-bs-target="#ModalEditarRol<?php echo e($user->id); ?>" class="btn btn-outline-success">Editar</a>
                </td>
              </tr>
              
              <!-- Modal para Editar Rol -->
              <div class="modal fade" id="ModalEditarRol<?php echo e($user->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h1 class="modal-title fs-5" id="exampleModalLabel">Editar Roles para <?php echo e($user->name); ?></h1>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                      <form action="<?php echo e(route('asignar.update', $user->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('PUT')); ?>

                        
                        <ul class="list-unstyled">
                          <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                              <input type="checkbox" name="roles[]" value="<?php echo e($roles->id); ?>" id="role_<?php echo e($roles->id); ?>">
                              <label for="role_<?php echo e($roles->id); ?>"><?php echo e($roles->name); ?></label>
                            </li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                        </ul>
                        <button class="btn btn-outline-success" type="submit">Asignar Rol</button>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
        
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>        
      </tr>
    </tbody>
  </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siat_facturacion\resources\views/userpermi.blade.php ENDPATH**/ ?>