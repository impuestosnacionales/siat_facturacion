<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Contribuyente</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col col-md-12 col-sm-12 justify-content-center">
                <font align="center"><h1>Ver Contribuyente</h1></font>
                <a href="<?php echo e(route('contribuyente')); ?>" class="btn btn-primary" role="button">Volver a lista</a>
                <div class="card">
                <?php echo csrf_field(); ?>
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> 
                    <br>
  <div class="mb-3">
    <label class="form-label">Descripcion Producto Contribuyente: <strong><?php echo e($contribuyente->Descripcion_Producto_Contribuyente); ?></strong></label>
  </div>
  <div class="mb-3">
    <label class="form-label">Precio: <strong><?php echo e($contribuyente->Precio); ?></strong></label>
  </div>
  <div class="mb-3">
    <label class="form-label">Unidad de Medida: <strong><?php echo e($contribuyente->Unidad_de_Medida); ?></strong></label>
  </div>
  <input type="button" class="btn btn-primary" name="Submit" value="imprimir" onclick="javascript:window.print()">
  <br>
  <form action="<?php echo e(route('contribuyente.destroy',$contribuyente->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo e(method_field('DELETE')); ?>

    <input class="btn btn-danger form-control" type="submit" value="eliminar" onclick="return EliminarContribuyente('¿Desea eliminar este contribuyente?') ">
  </form>

                </div>

            </div>
        </div>
    </div>
</body>
<script>
    function EliminarContribuyente(value){
        action=confirm(value) ? true: events.prevenDefault();
    }
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</html><?php /**PATH C:\xampp\htdocs\sistema_simulador\resources\views/Coso/contribuyente_ver.blade.php ENDPATH**/ ?>