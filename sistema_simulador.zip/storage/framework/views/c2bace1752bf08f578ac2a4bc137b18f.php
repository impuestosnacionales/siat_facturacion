<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col col-md-12 col-sm-12 justify-content-center">
                <h1>Formulario Contribuyente</h1>
                <a href="<?php echo e(route('contribuyente')); ?>" class="btn btn-primary" role="button">Lista de Contribuyentes</a>
                <form action="<?php echo e(route('contribuyente.update', $contribuyente->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('PUT')); ?>

                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> 
                    <br>
  <div class="mb-3">
    <label class="form-label">Descripcion Producto Contribuyente</label>
    <input type="text" class="form-control"  name="Descripcion_Producto_Contribuyente" value="<?php echo e($contribuyente->Descripcion_Producto_Contribuyente); ?>"> 
  </div>
  <div class="mb-3">
    <label class="form-label">Precio</label>
    <input type="number" class="form-control" id="exampleInputPassword1"  name="Precio" value="<?php echo e($contribuyente->Precio); ?>">
  </div>
  <div class="mb-3">
    <label class="form-label">Unidad de Medida</label>
    <input type="text" class="form-control" placeholder="Unidad de Medida" name="Unidad_de_Medida" value="<?php echo e($contribuyente->Unidad_de_Medida); ?>">
  </div>
  <button type="submit" class="btn btn-primary">Editar</button>
</form>
            </div>
        </div>
    </div>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</html><?php /**PATH C:\xampp\htdocs\sistema_simulador\resources\views/Coso/contribuyente_editar.blade.php ENDPATH**/ ?>