<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col col-md-12 col-sm-12 justify-content-center">
                <font align="center"><h1>Formulario de Producto</h1></font>
                <a href="<?php echo e(route('producto')); ?>" class="btn btn-primary" role="button">Lista de productos</a>
                <form action="<?php echo e(route('producto.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> 
                    <br>
  <div class="mb-3">
    <label class="form-label">Codigo_Producto_SIN</label>
    <input type="number" class="form-control"  name="Codigo_Producto_SIN"> 
  </div>
  <div class="mb-3">
    <label class="form-label">Codigo_Actividad_CAEB</label>
    <input type="number" class="form-control" id="exampleInputPassword1"  name="Codigo_Actividad_CAEB">
  </div>
  <div class="mb-3">
    <label class="form-label">Descripcion_o_producto_SIN</label>
    <input type="text" class="form-control"  name="Descripcion_o_producto_SIN">
  </div>
  <div class="card">
    <div class="card-body">
        <div class="row">
        <div class="col-3 col-mb-3 col-sm-3">
            <label>Contribuyente</label>
            <select class="form-select" name="pid_contribuyente" id="pid_contribuyente" aria-label="Default select example">
            <?php $__currentLoopData = $contribuyente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <option value="<?php echo e($contr->id); ?>"><?php echo e($contr->Descripcion_Producto_Contribuyente); ?></option>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-3">
            <label>Precio</label>
            <input type="number" class="form-control" id="exampleInputPassword1" placeholder="Añade el precio" name="p_precio" id="p_precio">
        </div>
        <div class="col-lg-3 col-md-3 col-sm-3">
            <label>Tarifa</label>
            <input type="number" class="form-control" id="exampleInputPassword1" placeholder="Añade la tarifa" name="p_tarifa" id="p_tarifa">
        </div>
        <div class="col-lg-3 col-md-3 col-sm-3">
            <br>
            <button type="button" id="bt_agregar" class="btn btn-primary">Agregar</button>
        </div>
        <div>
            <br>
        <table class="table">
            <thead class="table-primary table-bordered border-primary">
                <tr>
                    <th>Opciones</th>
                    <th>Nombre del Contribuyente</th>
                    <th>Precio</th>
                    <th>Tarifa</th>
                    <th>Total</th>
                </tr>
           </thead>
            <tbody id="tabla_body">

           </tbody>
        </table>
        </div>
        </div>
    </div>
  </div>
  <button type="submit" class="btn btn-primary form-control">Añadir</button>
</form>
            </div>
        </div>
    </div>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
<script>
    $(document).ready(function(){
        $('#bt_agregar').click(function(){
            agregar();
        });
    });
    var cont=0;
    function agregar(){
        var id_contribuyente=$("#pid_contribuyente").val();
        var precio=$("#p_precio").val();
        var tarifa=$("#p_tarifa").val();
        var Descripcion_Producto_Contribuyente=$("#pid_contribuyente option::selected").text();
        if(precio!="" && precio>0 %% tarifa!="" && tarifa>0){
            var fila='<tr class="selected" id="fila'+cont+'"><td><button type="button" class="btn btn-danger" onclick="eliminar('+cont+')">X</button></td><td><input type="hidden" name="id_contribuyente[]" value="'+id_contribuyente+'">Nombre</td><td><input type="number" name="precio[]" value="+'precio'+"></td><td><input type="number" name="tarifa[]" value="'+tarifa+'"></td><td>'+precio*tarifa+'</td></tr>'
            cont++;
            $('#tabla_body').append(fila);
        }else{
            aler("Porfavor rellenar los campos faltantes")
        }
    }
    function eliminar(pos){
        $("#fila"+pos).remove();
    }
</script>
</html><?php /**PATH C:\xampp\htdocs\sistema_simulador\resources\views/Coso/producto_crear.blade.php ENDPATH**/ ?>