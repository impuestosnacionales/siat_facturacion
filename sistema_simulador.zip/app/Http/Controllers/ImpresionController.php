<?php

namespace App\Http\Controllers;
use App\Models\Impresion;

use Illuminate\Http\Request;

class ImpresionController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        //
        $impresion=Impresion::all();
        return view('Impresion.impresion',['impresion'=>$impresion]);
    }

    public function create()
    {
        //
        return view('Impresion.impresion_crear');
    }

    public function store(Request $request)
    {
        //
        if ($request->hasFile('logo')) {
            $request->validate(Impresion::$rules);
            $impresion= new Impresion($request->all());
            $logoFile = $request->file('logo');
            $filename = time() . '.' . $logoFile->getClientOriginalExtension();
            dd($filename);
            $logoFile->move(public_path('assets/img/'), $filename);
            $impresion->logo = 'assets/img/' . $filename;

        } else {
            $impresion = new Impresion($request->except('logo'));
            $impresion->logo = 'assets/img/predeterminado.png';
        }
        $impresion->save();
        return redirect()->action([ImpresionController::class, 'index']);
    }

    public function show(string $id)
    {
        //
        $impresion=Impresion::findorFail($id);
        return view('Impresion.impresion_ver',['impresion'=>$impresion]);
    }

}
