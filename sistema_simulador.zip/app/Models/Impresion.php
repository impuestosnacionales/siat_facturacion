<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Impresion extends Model
{
    use HasFactory;
    protected $primaryKey="id";
    protected $fillable=['logo', 'opcion'];
    protected $hidde=['id'];

    public static $rules = [
        'logo' => 'required|image|mimes:jpeg,png|max:2048',
    ];
}
